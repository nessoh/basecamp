Rails.application.routes.draw do
  devise_for :users
  resources :projects do
    member do
      get :remove_admin
      get :set_admin
    end
  end
  root 'projects#index'
end
